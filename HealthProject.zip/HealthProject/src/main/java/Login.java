import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Login")
public class Login extends HttpServlet {
			@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
				try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("select * from registrationhealth where t1=? and t5=?");
			ps.setString(1,a);
			ps.setString(2,b);
			ResultSet rs=ps.executeQuery();
			int x=0;
			while(rs.next())
			{
				x=1;//when there is data
			}
			if(x==1)
			{
				res.sendRedirect("aboutus.html");
			}
			else
			{
				res.sendRedirect("index.html");
			}
	}	
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		}}
